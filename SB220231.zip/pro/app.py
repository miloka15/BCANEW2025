import os
from flask import Flask, request, jsonify, send_from_directory
from pymongo import MongoClient
from base64 import b64encode, b64decode
from Crypto.Cipher import AES, DES3
from Crypto.Random import get_random_bytes
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

# MongoDB setup
MONGO_URI = os.getenv("MONGO_URI")
max_pool_size = int(os.getenv("MAX_POOL_SIZE", 50))  # default to 50
client = MongoClient(MONGO_URI)
db = client["userdb"]
collection = db["users"]

# Padding helpers
def pad(text, block_size):
    padding_len = block_size - len(text) % block_size
    return text + chr(padding_len) * padding_len

def unpad(text):
    return text[:-ord(text[-1])]

# AES encrypt/decrypt
def encrypt_aes(plain_text, key):
    key = key.ljust(32)[:32].encode()
    iv = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_text = pad(plain_text, AES.block_size)
    encrypted = cipher.encrypt(padded_text.encode())
    return {
        "iv": b64encode(iv).decode(),
        "data": b64encode(encrypted).decode(),
        "alg": "AES"
    }

def decrypt_aes(data, key):
    key = key.ljust(32)[:32].encode()
    iv = b64decode(data["iv"])
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(b64decode(data["data"]))
    return unpad(decrypted.decode())

# 3DES encrypt/decrypt
def encrypt_3des(plain_text, key):
    key = key.ljust(24)[:24].encode()
    iv = get_random_bytes(8)
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    padded_text = pad(plain_text, DES3.block_size)
    encrypted = cipher.encrypt(padded_text.encode())
    return {
        "iv": b64encode(iv).decode(),
        "data": b64encode(encrypted).decode(),
        "alg": "3DES"
    }

def decrypt_3des(data, key):
    key = key.ljust(24)[:24].encode()
    iv = b64decode(data["iv"])
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    decrypted = cipher.decrypt(b64decode(data["data"]))
    return unpad(decrypted.decode())

# Route to register user
@app.route("/register", methods=["POST"])
def register():
    req_data = request.json
    username = req_data.get("username")
    password = req_data.get("password")
    gmail = req_data.get("gmail")
    algorithm = req_data.get("algorithm")

    key = os.getenv("SECRET_KEY", "defaultsecret")

    # Check if user already exists
    if collection.find_one({"username": username}):
        return jsonify({"error": "User already exists"}), 409

    # Encrypt both password and gmail
    if algorithm == "AES":
        encrypted_pass = encrypt_aes(password, key)
        encrypted_gmail = encrypt_aes(gmail, key)
    elif algorithm == "3DES":
        encrypted_pass = encrypt_3des(password, key)
        encrypted_gmail = encrypt_3des(gmail, key)
    else:
        return jsonify({"error": "Unsupported algorithm"}), 400

    # Save to DB
    collection.insert_one({
        "username": username,
        "password": encrypted_pass,
        "gmail": encrypted_gmail
    })
    return jsonify({"message": "User registered successfully!"})

# Route to retrieve Gmail if password matches
@app.route("/retrieve", methods=["POST"])
def retrieve():
    req_data = request.json
    username = req_data.get("username")
    password_input = req_data.get("password")

    key = os.getenv("SECRET_KEY", "defaultsecret")

    user = collection.find_one({"username": username})
    if not user:
        return jsonify({"error": "User not found"}), 404

    encrypted_pass = user["password"]
    encrypted_gmail = user["gmail"]
    algorithm = encrypted_pass["alg"]

    try:
        if algorithm == "AES":
            actual_password = decrypt_aes(encrypted_pass, key)
        elif algorithm == "3DES":
            actual_password = decrypt_3des(encrypted_pass, key)
        else:
            return jsonify({"error": "Unsupported encryption"}), 400
    except:
        return jsonify({"error": "Decryption failed"}), 500

    if password_input != actual_password:
        return jsonify({"error": "Incorrect password"}), 401

    # Decrypt Gmail
    if algorithm == "AES":
        gmail = decrypt_aes(encrypted_gmail, key)
    else:
        gmail = decrypt_3des(encrypted_gmail, key)

    return jsonify({"gmail": gmail})

# Serve frontend
@app.route("/")
def home():
    return send_from_directory(".", "index.html")

if __name__ == "__main__":
    app.run(debug=True)